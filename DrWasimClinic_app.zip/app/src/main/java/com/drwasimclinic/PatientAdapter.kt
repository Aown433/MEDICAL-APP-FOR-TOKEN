package com.drwasimclinic

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PatientAdapter(var items: MutableList<Patient>) : RecyclerView.Adapter<PatientAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvName: TextView = v.findViewById(R.id.tvName)
        val tvPhone: TextView = v.findViewById(R.id.tvPhone)
        val tvToken: TextView = v.findViewById(R.id.tvToken)
        val tvTime: TextView = v.findViewById(R.id.tvTime)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_patient, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = items[position]
        holder.tvName.text = p.name
        holder.tvPhone.text = p.phone
        holder.tvToken.text = "Token: ${p.token}"
        holder.tvTime.text = "${p.start_time} - ${p.end_time}"
    }

    override fun getItemCount(): Int = items.size

    fun updateData(newList: MutableList<Patient>) {
        items = newList
        notifyDataSetChanged()
    }
}
