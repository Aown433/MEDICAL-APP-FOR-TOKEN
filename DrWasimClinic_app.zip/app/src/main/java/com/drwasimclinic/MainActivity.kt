package com.drwasimclinic

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    lateinit var db: PatientDatabaseHelper
    lateinit var edtName: EditText
    lateinit var edtPhone: EditText
    lateinit var edtToken: EditText
    lateinit var btnSave: Button
    lateinit var btnCopyMsg: Button
    lateinit var rvPatients: RecyclerView
    lateinit var adapter: PatientAdapter
    lateinit var edtSearch: EditText

    val clinicStartHour = 16 // 4 PM
    val clinicStartMinute = 30 // 4:30

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = PatientDatabaseHelper(this)

        edtName = findViewById(R.id.edtName)
        edtPhone = findViewById(R.id.edtPhone)
        edtToken = findViewById(R.id.edtToken)
        btnSave = findViewById(R.id.btnSave)
        btnCopyMsg = findViewById(R.id.btnCopyMsg)
        rvPatients = findViewById(R.id.rvPatients)
        edtSearch = findViewById(R.id.edtSearch)

        rvPatients.layoutManager = LinearLayoutManager(this)
        adapter = PatientAdapter(mutableListOf())
        rvPatients.adapter = adapter

        refreshList()

        btnSave.setOnClickListener {
            val name = edtName.text.toString().trim()
            val phone = edtPhone.text.toString().trim()
            val tokenStr = edtToken.text.toString().trim()
            if (name.isEmpty() || phone.isEmpty() || tokenStr.isEmpty()) {
                Toast.makeText(this, "Name, phone and token required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val token = tokenStr.toInt()
            val (start, end) = calculateDisplayedWindow(token)
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val id = db.insertPatient(token, name, phone, start, end, dateStr, "")
            if (id > 0) {
                Toast.makeText(this, "Token saved", Toast.LENGTH_SHORT).show()
                edtName.text.clear(); edtPhone.text.clear(); edtToken.text.clear()
                refreshList()
            } else {
                Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show()
            }
        }

        btnCopyMsg.setOnClickListener {
            val tokenStr = edtToken.text.toString().trim()
            if (tokenStr.isEmpty()) {
                Toast.makeText(this, "Enter token to prepare message", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val token = tokenStr.toInt()
            val (start, end) = calculateDisplayedWindow(token)
            val msg = buildUrduMessage(token, start, end)
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("clinic_msg", msg))
            Toast.makeText(this, "Message copied to clipboard. Paste into SMS.", Toast.LENGTH_LONG).show()
        }

        edtSearch.addTextChangedListener(object: TextWatcher{
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val q = s.toString().trim()
                val list = db.searchPatients(q)
                adapter.updateData(list)
            }
        })
    }

    fun refreshList(){
        val list = db.getAllPatients()
        adapter.updateData(list)
    }

    // For token T, doctor gives 10-minute slot starting from 4:30.
    // But message must show a 20-minute window centered or starting at token start.
    // We'll show: displayStart = tokenStart, displayEnd = tokenStart + 20 minutes
    fun calculateDisplayedWindow(token: Int): Pair<String,String> {
        // token 1 => starts at 4:30
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, clinicStartHour)
        cal.set(Calendar.MINUTE, clinicStartMinute)
        cal.set(Calendar.SECOND, 0)
        val addMinutes = (token - 1) * 10
        cal.add(Calendar.MINUTE, addMinutes)
        val start = cal.time
        val endCal = cal.clone() as Calendar
        endCal.add(Calendar.MINUTE, 20)
        val sdf = SimpleDateFormat("h:mm", Locale.getDefault())
        return Pair(sdf.format(start), sdf.format(endCal.time))
    }

    fun buildUrduMessage(token: Int, start: String, end: String): String {
        return "محترم مریض، آپ کا ٹوکن نمبر $token ہے۔\nآپ کا چیک اپ $start سے $end شام کے درمیان متوقع ہے۔\nبراہ کرم وقت پر تشریف لائیں۔\nشکریہ — Dr. Wasim Akhtar Clinic, Vehari."
    }
}
