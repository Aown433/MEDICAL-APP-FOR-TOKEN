package com.drwasimclinic

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Patient(
    val id: Int,
    val token: Int,
    val name: String,
    val phone: String,
    val start_time: String,
    val end_time: String,
    val date: String,
    val prescription_path: String
)

class PatientDatabaseHelper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        const val DB_NAME = "clinic.db"
        const val DB_VERSION = 1
        const val TABLE = "patients"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val create = """CREATE TABLE $TABLE (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token INTEGER,
            name TEXT,
            phone TEXT,
            start_time TEXT,
            end_time TEXT,
            date TEXT,
            prescription_path TEXT
        )"""
        db.execSQL(create)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE")
        onCreate(db)
    }

    fun insertPatient(token: Int, name: String, phone: String, start: String, end: String, date: String, presPath: String): Long {
        val db = writableDatabase
        val cv = ContentValues()
        cv.put("token", token)
        cv.put("name", name)
        cv.put("phone", phone)
        cv.put("start_time", start)
        cv.put("end_time", end)
        cv.put("date", date)
        cv.put("prescription_path", presPath)
        return db.insert(TABLE, null, cv)
    }

    fun getAllPatients(): MutableList<Patient> {
        val list = mutableListOf<Patient>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE ORDER BY id DESC", null)
        if (cursor.moveToFirst()) {
            do {
                list.add(Patient(
                    cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                    cursor.getInt(cursor.getColumnIndexOrThrow("token")),
                    cursor.getString(cursor.getColumnIndexOrThrow("name")),
                    cursor.getString(cursor.getColumnIndexOrThrow("phone")),
                    cursor.getString(cursor.getColumnIndexOrThrow("start_time")),
                    cursor.getString(cursor.getColumnIndexOrThrow("end_time")),
                    cursor.getString(cursor.getColumnIndexOrThrow("date")),
                    cursor.getString(cursor.getColumnIndexOrThrow("prescription_path"))
                ))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }

    fun searchPatients(q: String): MutableList<Patient> {
        val list = mutableListOf<Patient>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE WHERE name LIKE ? OR phone LIKE ? ORDER BY id DESC", arrayOf("%$q%","%$q%"))
        if (cursor.moveToFirst()) {
            do {
                list.add(Patient(
                    cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                    cursor.getInt(cursor.getColumnIndexOrThrow("token")),
                    cursor.getString(cursor.getColumnIndexOrThrow("name")),
                    cursor.getString(cursor.getColumnIndexOrThrow("phone")),
                    cursor.getString(cursor.getColumnIndexOrThrow("start_time")),
                    cursor.getString(cursor.getColumnIndexOrThrow("end_time")),
                    cursor.getString(cursor.getColumnIndexOrThrow("date")),
                    cursor.getString(cursor.getColumnIndexOrThrow("prescription_path"))
                ))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }
}
